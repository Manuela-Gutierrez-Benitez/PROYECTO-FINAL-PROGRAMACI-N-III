from model_ml.model import predict_label
from ui.ui_model import menu


def main():
    menu()

if __name__ == "__main__":
    main()